

const totalSuppliersAmount = ()=>{

    let suppliersData = JSON.parse(localStorage.getItem("suppliers"))
    let total=0
    suppliersData.forEach(element => {
        total+=Number(element.amount)
    })
    document.getElementById("totalSupplier").innerHTML = `Total suppliers is ${total}`

    let row = document.createElement("tr")
    let cell = document.createElement("td")
    cell.colSpan = "3";
    row.appendChild(cell)
    document.getElementById("suppliersTable").appendChild(row)
    cell.innerHTML= "Added  "+ total
    cell.style.backgroundColor="red"
    // debugging the repetitive display of totalSuppliersAmount cell 
}

export default totalSuppliersAmount
