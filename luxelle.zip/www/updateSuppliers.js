let form = document.querySelector(".form")
let dataTable = document.getElementById("data")
let insightTable = document.getElementById("insight")
let suppliersTable = document.getElementById("suppliersTable")
let graphs = document.getElementById("canvas")
let db = new Localbase("db");

function loadSuppliers(){
    

}