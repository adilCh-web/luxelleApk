

function logOut(){
    document.getElementById("main").style.display = "none";
    document.getElementById("logInComponent").style.display = "flex";

}

export default logOut